"""Verify supplied hashes and recompute objective v1 summaries; no model calls.

Run with standard-library Python from an extracted examiner supplement.
This supplementary analysis does not import or execute the historical harness.
"""
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'evaluation/results/qwen2.5-3b-v1'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def rows(name):
    return [json.loads(line) for line in (RESULTS / name).read_text(encoding='utf-8').splitlines() if line.strip()]


def percentile(values, fraction):
    ordered = sorted(values)
    return ordered[math.ceil(fraction * len(ordered)) - 1]


def runtime(records):
    values = [r['request_result']['latency_seconds'] for r in records]
    return {
        'requests': len(records),
        'successful_requests': sum(r['request_result']['ok'] for r in records),
        'finish_reasons': dict(Counter(r['request_result'].get('finish_reason') for r in records)),
        'p50_seconds_nearest_rank': percentile(values, .5),
        'p95_seconds_nearest_rank': percentile(values, .95),
        'mean_prompt_tokens': mean(r['request_result']['prompt_tokens'] for r in records),
        'mean_completion_tokens': mean(r['request_result']['completion_tokens'] for r in records),
    }


def main():
    checks = json.loads((ROOT / 'FILE_HASHES.json').read_text(encoding='utf-8'))
    for relative, expected in checks.items():
        path = (ROOT / relative).resolve()
        assert ROOT in path.parents, relative
        assert digest(path.read_bytes()) == expected, f'Package hash mismatch: {relative}'
    manifest = json.loads((RESULTS / 'frozen_configuration_and_source_manifest.json').read_text(encoding='utf-8'))
    combined = hashlib.sha256()
    for entry in manifest['source_snapshot']['files']:
        raw = (ROOT / entry['path']).read_bytes()
        assert digest(raw) == entry['sha256'], entry['path']
        combined.update(entry['path'].encode('utf-8') + b'\0' + raw + b'\0')
    assert combined.hexdigest() == manifest['source_snapshot']['combined_sha256']
    incident = rows('incident_runs.jsonl')
    rag = rows('rag_runs.jsonl')
    spec = json.loads((ROOT / 'evaluation/benchmark_v1.json').read_text(encoding='utf-8'))
    expected_incident = {(s['id'], r) for s in spec['incident_scenarios'] for r in (1, 2, 3)}
    expected_rag = {(q['id'], c, r) for q in spec['rag_questions'] for c in ('rag', 'no_rag') for r in (1, 2, 3)}
    assert len(incident) == len(expected_incident) == 72
    assert {(r['scenario_id'], r['repeat']) for r in incident} == expected_incident
    assert len(rag) == len(expected_rag) == 72
    assert {(r['question_id'], r['condition'], r['repeat']) for r in rag} == expected_rag
    assert all(r['spec_sha256'] == manifest['spec_sha256'] for r in incident + rag)
    severities = ['ok', 'warning', 'high', 'critical']
    confusion = {g: {p: 0 for p in severities} for g in severities}
    for row in incident:
        assert row['parsed']['ok']
        confusion[row['gold_severity']][row['parsed']['severity']] += 1
    precision, recall, f1 = [], [], []
    for label in severities:
        tp = confusion[label][label]
        predicted = sum(confusion[g][label] for g in severities)
        gold = sum(confusion[label].values())
        p = tp / predicted if predicted else 0
        r = tp / gold if gold else 0
        precision.append(p); recall.append(r)
        f1.append(2 * p * r / (p + r) if p + r else 0)
    agreement = sum(confusion[s][s] for s in severities)
    stable = sum(len({r['parsed']['signature'] for r in incident if r['scenario_id'] == s['id']}) == 1 for s in spec['incident_scenarios'])
    healthy = [r for r in incident if r['scenario_id'] in ('C01', 'C02', 'C03', 'C21')]
    c23 = [r for r in incident if r['scenario_id'] == 'C23']
    retrieval = json.loads((RESULTS / 'retrieval.json').read_text(encoding='utf-8'))
    output = {
        'verification': 'PASS', 'source_manifest_files_verified': len(manifest['source_snapshot']['files']),
        'combined_source_sha256': combined.hexdigest(),
        'incident': {
            'confusion_matrix': confusion, 'correct_frozen_labels': agreement, 'total': len(incident),
            'exact_agreement_percent': agreement / len(incident) * 100,
            'macro_precision': mean(precision), 'macro_recall': mean(recall), 'macro_f1': mean(f1),
            'stable_signature_scenarios': stable, 'scenario_count': 24,
            'healthy_or_no_impact_cases': ['C01', 'C02', 'C03', 'C21'], 'healthy_or_no_impact_runs': len(healthy),
            'healthy_or_no_impact_escalations': sum(r['parsed']['severity'] != 'ok' for r in healthy),
            'c23_frozen_gold': 'ok', 'c23_predictions': [r['parsed']['severity'] for r in c23],
            'c23_signatures': [r['parsed']['signature'] for r in c23],
            'optional_post_hoc_c23_exclusion': {'correct': agreement - 3, 'total': 69, 'percent': (agreement - 3) / 69 * 100, 'primary_result_replaced': False},
            'runtime': runtime(incident),
        },
        'retrieval': {'questions': len(retrieval['questions']), 'top_four_successes': sum(q['relevant_runbook'] in q['retrieved_sources'][:4] for q in retrieval['questions'])},
        'rag': {condition: runtime([r for r in rag if r['condition'] == condition]) for condition in ('rag', 'no_rag')},
        'boundary': 'Objective recomputation from retained rows only. No new model run, human score, source authorship authentication, or operational-effectiveness claim.',
    }
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
