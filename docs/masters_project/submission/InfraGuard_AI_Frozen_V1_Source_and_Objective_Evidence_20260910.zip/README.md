# InfraGuard AI frozen v1 source and objective evidence — examiner supplement

Assembled 10 September 2026 from retained files. This supplement accompanies the thesis; it is a local deliverable and has not been published. The exact attachment filename is `InfraGuard_AI_Frozen_V1_Source_and_Objective_Evidence_20260910.zip`.

## Contents and evidence boundary

- The six benchmark dependency/specification/harness files and twenty runbooks listed by the frozen source manifest. All 26 files were recovered byte-for-byte from an existing source archive and match every recorded SHA-256 and the combined source digest `5f3f1460b9441e39e4f5780df542e1f445768fc8428f5ed3e8cbdc27d4b3769c`.
- Frozen specification: `evaluation/benchmark_v1.json`; SHA-256 `7936721040238a95c57d51ec6fa86b9ee104b6b4021df83efdf903604ab58fee`.
- Unchanged historical harness: `evaluation/run_benchmark.py`; SHA-256 `c7acf90ac379acf737c86c43d403ee096f618d32f77ed6ff18354a730a9bff8a`.
- Four unchanged objective records in `evaluation/results/qwen2.5-3b-v1/`: `incident_runs.jsonl`, `rag_runs.jsonl`, `retrieval.json`, and `incident_objective_scores.csv`.
- `evaluation/results/qwen2.5-3b-v1/frozen_configuration_and_source_manifest.json` is a clearly labelled derived manifest: retained configuration/source fields are unchanged; human-assessment metadata is omitted. It records the original retained manifest's hash and each included evidence file's hash.
- `verify_and_recompute.py` is a NEW standard-library helper for read-only hash verification and objective recomputation. It is not part of the historical experiment. `verified_objective_summary.json` records its output when this supplement was assembled; the optional C23 exclusion is explicitly post hoc, not a replacement primary result.
- `FILE_HASHES.json` identifies all payload files other than itself. The archive's external SHA-256 identifies the complete delivered ZIP.

No human participant records, SUS workbook, practitioner reports, assessor templates/scores, simulated scores, historical human aggregates, credentials, `.env` files, or application database are included. Fixture prompts/outputs are synthetic experiment records. This is not the current v2 implementation or the source snapshot for the 180-test/89% software-verification receipt.

## Recompute the reported objective evidence without model calls

Extract the archive into a separate directory. With standard-library Python available, run:

```text
python verify_and_recompute.py
```

The helper verifies the included hashes, all 26 historical source files, the combined digest, and the 72 unique incident and 72 unique RAG/no-RAG response keys. It then computes the confusion matrix, precision/recall/F1, signature repeat stability, healthy/no-impact denominator, C23 behaviour, top-four retrieval and runtime/token summaries. It prints JSON and does not modify evidence or contact a model. It recomputes values from the retained parsed outputs; it does not independently validate diagnosis, human authorship or institutional ethics.

## What the historical harness actually measured

The manifest records Python 3.11.16 (GCC 14.2.0), Ollama 0.30.11, qwen2.5:3b at Q4_K_M and model digest `357c53fb659c5076de1d65ccb0b397446227b71a42be9d1603d46168015c9e4b`. Temperature was 0.0. Calls went directly to Ollama through the OpenAI-compatible chat-completions client; the benchmark did not exercise the LangChain multi-tool incident loop.

The unchanged harness configures a 300-second model-client timeout and zero automatic SDK retries; incident and runbook completions are capped at 320 and 420 tokens respectively. Elapsed time uses `time.perf_counter()` immediately around the model client call, before output parsing. RAG source retrieval/context construction occurs before this timer, so these timings measure model-request latency, not end-to-end RAG latency. Percentiles use the nearest-rank order statistic at `ceil(p*n)` (one-based); for these even sample sizes the p50 is not the mean of the two central values. All 144 retained requests succeeded with finish reason `stop`; none is recorded as timeout or token-limit termination.

Requests were serial and unrandomised: C01–C24, three consecutive repetitions per scenario; R01–R12, three RAG runs followed by three no-RAG runs per question. Every call supplied a new system/user message pair. No random seed, warm-up stage, explicit model unload/KV-cache reset, or between-request hardware-state reset was set by the harness. The retrieval phase calls index construction against the historical persistent `./chroma_db` path; no clean pre-run index/cache-state receipt is retained. Fresh message pairs do not imply a cleared model cache.

Incident completion timestamps span 18 August 2026 16:39:13–16:52:11 UTC; RAG/no-RAG completion timestamps span 16:53:39–17:12:04 UTC. The manifest's `started_or_resumed_at_utc` is a stage/resume timestamp, not the start of the first incident request.

## Generation and environment limits

This supplement preserves the exact source files identified by the 26-file benchmark manifest and the retained observations. It is not a complete container image, dependency lock, installed-package snapshot, model-weight distribution, ONNX model cache, Chroma index snapshot or host image. Exact CPU/GPU/RAM, OS/kernel/container image digest, dependency versions, concurrent host load and initial model/index/cache state were not retained in the available benchmark record. The general development-machine description must not be substituted for those historical execution facts. Model identity is recorded by digest but weights are not included.

The historical harness requires the original compatible external dependencies/model service to generate fresh outputs. Its direct imports and dependent package versions prevent a claim that this ZIP alone re-creates the original runtime. The preserved source and rows support inspection and objective recomputation; deterministic regeneration of all outputs/timings is not established. Any future generation must use a new output directory and separately identified runtime, and must not overwrite these historical rows. Absolute latency is descriptive, host-specific and subject to unmeasured warm-up/cache/order effects; the retained timing difference does not isolate a causal retrieval overhead or establish portable performance.

## C23 and healthy/no-impact interpretation

C23's frozen v1 prompt explicitly treated unchanged acknowledged conditions as accepted non-issues and requested severity `ok` with signature reuse. Its `ok` gold label is therefore a historical acknowledgement-conditioned exception to telemetry-only severity definitions. All three C23 responses were `ok`, but each returned `none:healthy:/`, not the expected `prometheus:disk-low:/`; repeat stability is not proof of correct condition identity or successful acknowledgement reuse.

The primary agreement remains 29/72 (40.3%) under the frozen v1 labels. A separately labelled optional post hoc C23 exclusion gives 26/69 (37.7%). Current v2 presentation masking does not authorise a severity downgrade; v1 outputs do not validate that current rule. The healthy/no-impact false-positive denominator is C01–C03 plus C21: twelve runs, all predicted `ok`. C23's three acknowledged-degradation runs are reported separately.

The project repository address is https://github.com/sagesta/infraguad_ai ; this is a general project locator, not a claim that this exact supplement, uncommitted local benchmark package or complete historical runtime is available at that URL. The accompanying ZIP is the specific examiner-access artifact. No publication, deposit DOI, remote upload or clean published-release verification is asserted.
